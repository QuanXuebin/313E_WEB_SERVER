#!/bin/sh

LEDGPIO=`cat /tmp/gpio_upd_led`
LEDVAL=1

while [ 1 = 1 ]; do
    if [ ! -d /sys/class/gpio/gpio$LEDGPIO ]; then
        echo $LEDGPIO > /sys/class/gpio/export
    fi
    echo out      > /sys/class/gpio/gpio$LEDGPIO/direction
    echo $LEDVAL  > /sys/class/gpio/gpio$LEDGPIO/value
    echo $LEDGPIO > /sys/class/gpio/unexport

    if [ x"$LEDVAL" = x"1" ]; then
        LEDVAL=0
    else
        LEDVAL=1
    fi
    sleep 1
done

