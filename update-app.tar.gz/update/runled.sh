#!/bin/sh

GREEN=1
while [ 1 = 1 ]; do
    if [ x"$GREEN" = x"1" ]; then
        GREEN=0
    else
        GREEN=1
    fi
    /tmp/update/setled.sh 0 $GREEN 0
    sleep 1
done

