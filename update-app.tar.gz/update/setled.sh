#!/bin/sh

R=$1
if [ "$R"x = ""x ]; then
    R=0
fi

G=$2
if [ "$G"x = ""x ]; then
    G=0
fi

B=$3
if [ "$B"x = ""x ]; then
    B=0
fi

# R
#if [ "$R"x != "-1"x ]; then
#   if [ ! -d /sys/class/gpio/gpio98 ]; then
#       echo 98 > /sys/class/gpio/export
#   fi
#   echo out > /sys/class/gpio/gpio98/direction
#   echo $R  > /sys/class/gpio/gpio98/value
#   echo 98  > /sys/class/gpio/unexport
#fi

# G
#if [ "$G"x != "-1"x ]; then
#   if [ ! -d /sys/class/gpio/gpio98 ]; then
#       echo 98 > /sys/class/gpio/export
#   fi
#   echo out > /sys/class/gpio/gpio98/direction
#   echo $G  > /sys/class/gpio/gpio98/value
#   echo 98  > /sys/class/gpio/unexport
#fi

# B
#if [ "$B"x != "-1"x ]; then
#   if [ ! -d /sys/class/gpio/gpio98 ]; then
#       echo 98 > /sys/class/gpio/export
#   fi
#   echo out > /sys/class/gpio/gpio98/direction
#   echo $B  > /sys/class/gpio/gpio98/value
#   echo 98  > /sys/class/gpio/unexport
#fi
